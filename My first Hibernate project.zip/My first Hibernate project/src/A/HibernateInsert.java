package A;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateInsert {

	void insert() {
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(Employee.class).configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		Employee ee = new Employee(102, "Rani");
		ss.save(ee); // 102
		tx.commit();
		System.out.println("Data Inserted............");
	}

	void update() {
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(Employee.class).configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		Employee ee = new Employee(102, "Rani");
		ss.update(ee); // 102
		tx.commit();
		System.out.println("Data Inserted............");
	}

	void delete() {
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(Employee.class).configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		Employee ee = new Employee(102, "Rani");
		ss.delete(ee); // 102
		tx.commit();
		System.out.println("Data Inserted............");
	}

}
